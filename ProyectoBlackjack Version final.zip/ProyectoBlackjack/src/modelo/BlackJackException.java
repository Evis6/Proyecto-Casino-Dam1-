package modelo;
/**
 * 
 */
public class BlackJackException extends Exception{
	/**
	 * 
	 * @param mensaje
	 */
	public BlackJackException(String mensaje) {
		super(mensaje);
		
	}

}
