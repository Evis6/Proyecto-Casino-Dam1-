package modelo;

import java.util.LinkedList;


public abstract class AgenteJuego {
	
	//se encarga de guardar las cartas se usa un linkedList pq es mas accesible a la ultima carta
	private LinkedList<Carta> mano;
	protected int total ;//guarda los puntos totales de la mano
	protected int ases;//guarda los ases porque puede valer 1 o 11

	 /**
	  * inicia mano vacia
	  * puntos y ases a 0;
	  */
	public AgenteJuego() {
		super();
		this.mano = new LinkedList<Carta>();
		this.total=0;
		this.ases=0;
	}

	/**
	 * 
	 * @param carta
	 * metodo que añade una carta a la mano (cartas del jugador)
	 */
	protected void añadirCarta(Carta carta) {
		mano.add(carta);
	}
	/**
	 * 
	 * @return puntos totales
	 */
	public int calcularPuntos() {

		//reiniciar valores
		total =0;
		ases=0;
		//recorre cartas
		for (Carta carta : mano) {
			//suma sus puntos
			total += carta.getValorNumerico();
			//en caso de que el valor de la carta sea un as se aumenta el valor de los ases
			if (carta.getValor() == Valor.AS) {
				ases++;
			}
		}


		//PARA AJUSTAR EL AS EN CASO DE QUE TE PASES DE 21
		while(total > 21 && ases >0) {
			//como vale 11 en caso de que te pases le resta 10 y vale 1
			total-=10;
			ases--;//solo puede haber un as con valor 11 entonces cuando hay 2 resta 1;

		}
		return total;
	}






	/**
	 * 
	 * @return devuelve las cartas (se usa para mostrarlo en consola)
	 */
	public LinkedList<Carta> getMano() {
		return mano;
	}
	/**
	 * 
	 * @return comprueba si se pasa de 21
	 */
	protected boolean estaPasado() {
		return calcularPuntos() > 21;
	}

	/**
	 * 
	 * @return devuelve los puntos actuales
	 */
	public int getTotal() {
		return total;
	}



}


