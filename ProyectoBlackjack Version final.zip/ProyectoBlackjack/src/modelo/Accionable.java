package modelo;

public interface Accionable {
	
	//metodos para pedir carta y plantarse los cuales se usan en el jugador y crupier
	void pedirCarta(Mazo mazo);
	void plantarse();
	

}
