package modelo;

public class Crupier extends AgenteJuego implements Accionable {


	private String nombre;
	private boolean plantarse; 
	private Carta cartaOculta;
	/**
	 * 
	 * @return nombre de cuprier
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * 
	 * @return si el cuprier esta plantado o no
	 */
	public boolean isPlantarse() {
		return plantarse;
	}


	public Crupier(String nombre) {
		super();
		this.nombre=nombre;
	}


	/**
	 * metodo para pedir carta implementado de accionable
	 */
    @Override
    public void pedirCarta(Mazo mazo) {

        // Revela carta oculta si existe
        if (cartaOculta != null) {
            añadirCarta(cartaOculta);
            cartaOculta = null;
        }

        // Lógica automática hasta 17
        while (calcularPuntos() < 17) {
            Carta carta = mazo.robarCarta();
            añadirCarta(carta);
        }

        plantarse = true;
    }
    /**
     * 
     * @param carta
     */
    public void setCartaOculta(Carta carta) {
        this.cartaOculta = carta;
    }
    /**
     * metodo para plantarse
     */
	@Override
	public void plantarse() {	
		plantarse=true;
	}

	
}
